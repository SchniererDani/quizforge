package hu.quizmaster.model;

/**
 * Absztrakt ősosztály, amely a kvízkérdések közös tulajdonságait és viselkedését írja le.
 * Megvalósítja az enkapszulációt és alapul szolgál a futásidejű polimorfizmushoz.
 */
public abstract class Question {
    private final String id;
    private final String questionText;
    private final int points;

    public Question(String id, String questionText, int points) {
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("A kérdés azonosítója nem lehet üres.");
        }
        if (questionText == null || questionText.isBlank()) {
            throw new IllegalArgumentException("A kérdés szövege nem lehet üres.");
        }
        if (points <= 0) {
            throw new IllegalArgumentException("A pontértéknek pozitívnak kell lennie.");
        }
        this.id = id;
        this.questionText = questionText;
        this.points = points;
    }

    public String getId() {
        return id;
    }

    public String getQuestionText() {
        return questionText;
    }

    public int getPoints() {
        return points;
    }

    /**
     * Polimorf metódus a válasz helyességének ellenőrzésére.
     * @param userInput a felhasználó által megadott válasz
     * @return true, ha a válasz helyes, egyébként false
     */
    public abstract boolean checkAnswer(String userInput);

    /**
     * Polimorf metódus a kérdés és a lehetséges opciók formázott megjelenítésére.
     */
    public abstract String getFormattedQuestion();

    @Override
    public String toString() {
        return String.format("[%s] %s (%d pont)", id, questionText, points);
    }
}
