package hu.quizmaster.model;

/**
 * Szöveges vagy számszerű választ váró kérdéstípus.
 */
public class TextAnswerQuestion extends Question {
    private final String correctAnswerText;

    public TextAnswerQuestion(String id, String questionText, int points, String correctAnswerText) {
        super(id, questionText, points);
        if (correctAnswerText == null || correctAnswerText.isBlank()) {
            throw new IllegalArgumentException("A helyes válasz szövege nem lehet üres.");
        }
        this.correctAnswerText = correctAnswerText.trim();
    }

    public String getCorrectAnswerText() {
        return correctAnswerText;
    }

    @Override
    public boolean checkAnswer(String userInput) {
        if (userInput == null || userInput.isBlank()) {
            return false;
        }
        return correctAnswerText.equalsIgnoreCase(userInput.trim());
    }

    @Override
    public String getFormattedQuestion() {
        return String.format("❓ %s (%d pont)\n   ✍️ Írd be a helyes választ:\n", getQuestionText(), getPoints());
    }
}
