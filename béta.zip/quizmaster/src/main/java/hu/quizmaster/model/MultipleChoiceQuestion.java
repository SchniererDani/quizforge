package hu.quizmaster.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Feleletválasztós kérdéstípus (pl. A, B, C, D opciókkal).
 */
public class MultipleChoiceQuestion extends Question {
    private final List<String> options;
    private final int correctOptionIndex;

    public MultipleChoiceQuestion(String id, String questionText, int points, List<String> options, int correctOptionIndex) {
        super(id, questionText, points);
        if (options == null || options.size() < 2) {
            throw new IllegalArgumentException("Legalább 2 választási opció szükséges.");
        }
        if (correctOptionIndex < 0 || correctOptionIndex >= options.size()) {
            throw new IllegalArgumentException("A helyes válasz indexe érvénytelen.");
        }
        this.options = new ArrayList<>(options);
        this.correctOptionIndex = correctOptionIndex;
    }

    public List<String> getOptions() {
        return Collections.unmodifiableList(options);
    }

    public int getCorrectOptionIndex() {
        return correctOptionIndex;
    }

    @Override
    public boolean checkAnswer(String userInput) {
        if (userInput == null || userInput.isBlank()) {
            return false;
        }
        String cleanInput = userInput.trim().toUpperCase();
        
        // Ellenőrzés betűjellel (A, B, C, D...)
        if (cleanInput.length() == 1 && cleanInput.charAt(0) >= 'A' && cleanInput.charAt(0) < ('A' + options.size())) {
            int selectedIndex = cleanInput.charAt(0) - 'A';
            return selectedIndex == correctOptionIndex;
        }

        // Ellenőrzés számmal (1, 2, 3...)
        try {
            int selectedNum = Integer.parseInt(cleanInput) - 1;
            return selectedNum == correctOptionIndex;
        } catch (NumberFormatException ignored) {
        }

        // Ellenőrzés szöveges egyezéssel
        return options.get(correctOptionIndex).equalsIgnoreCase(userInput.trim());
    }

    @Override
    public String getFormattedQuestion() {
        StringBuilder sb = new StringBuilder();
        sb.append("❓ ").append(getQuestionText()).append(" (").append(getPoints()).append(" pont)\n");
        char label = 'A';
        for (String option : options) {
            sb.append("   [").append(label++).append("] ").append(option).append("\n");
        }
        return sb.toString();
    }
}
