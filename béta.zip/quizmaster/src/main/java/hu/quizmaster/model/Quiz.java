package hu.quizmaster.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Egy komplett kvízt képviselő domain modell.
 */
public class Quiz {
    private final String id;
    private final String title;
    private final String category;
    private final String author;
    private final List<Question> questions;

    public Quiz(String id, String title, String category, String author, List<Question> questions) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("Quiz ID nem lehet üres.");
        if (title == null || title.isBlank()) throw new IllegalArgumentException("Quiz cím nem lehet üres.");
        this.id = id;
        this.title = title;
        this.category = (category != null && !category.isBlank()) ? category : "Általános";
        this.author = (author != null && !author.isBlank()) ? author : "Ismeretlen";
        this.questions = (questions != null) ? new ArrayList<>(questions) : new ArrayList<>();
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public String getAuthor() { return author; }
    public List<Question> getQuestions() { return Collections.unmodifiableList(questions); }

    public int getMaxPossiblePoints() {
        return questions.stream().mapToInt(Question::getPoints).sum();
    }

    public int getQuestionCount() {
        return questions.size();
    }

    @Override
    public String toString() {
        return String.format("%s [%s] (%d kérdés, max %d pont)", title, category, getQuestionCount(), getMaxPossiblePoints());
    }
}
