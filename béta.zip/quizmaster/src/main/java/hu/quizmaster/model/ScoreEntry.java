package hu.quizmaster.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Dicsőséglista elem, amely megvalósítja a Comparable interfészt a pontszám szerinti rendezéshez.
 */
public class ScoreEntry implements Comparable<ScoreEntry> {
    private final String playerName;
    private final String quizTitle;
    private final int score;
    private final int maxScore;
    private final String timestamp;

    public ScoreEntry(String playerName, String quizTitle, int score, int maxScore) {
        this.playerName = playerName;
        this.quizTitle = quizTitle;
        this.score = score;
        this.maxScore = maxScore;
        this.timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
    }

    public ScoreEntry(String playerName, String quizTitle, int score, int maxScore, String timestamp) {
        this.playerName = playerName;
        this.quizTitle = quizTitle;
        this.score = score;
        this.maxScore = maxScore;
        this.timestamp = timestamp;
    }

    public String getPlayerName() { return playerName; }
    public String getQuizTitle() { return quizTitle; }
    public int getScore() { return score; }
    public int getMaxScore() { return maxScore; }
    public String getTimestamp() { return timestamp; }

    /**
     * Rendezés: Pontszám szerint csökkenő sorrendben, egyenlőség esetén név szerint.
     */
    @Override
    public int compareTo(ScoreEntry other) {
        int scoreCompare = Integer.compare(other.score, this.score);
        if (scoreCompare != 0) {
            return scoreCompare;
        }
        return this.playerName.compareToIgnoreCase(other.playerName);
    }

    public String toFileFormat() {
        return String.format("%s|%s|%d|%d|%s", playerName, quizTitle, score, maxScore, timestamp);
    }

    public static ScoreEntry fromFileFormat(String line) {
        String[] parts = line.split("\\|");
        if (parts.length >= 5) {
            return new ScoreEntry(parts[0], parts[1], Integer.parseInt(parts[2]), Integer.parseInt(parts[3]), parts[4]);
        }
        throw new IllegalArgumentException("Érvénytelen rekord sor: " + line);
    }

    @Override
    public String toString() {
        return String.format("%-15s | %-20s | %d/%d pont | %s", playerName, quizTitle, score, maxScore, timestamp);
    }
}
