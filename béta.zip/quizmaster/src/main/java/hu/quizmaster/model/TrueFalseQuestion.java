package hu.quizmaster.model;

/**
 * Igaz / Hamis típusú kérdés.
 */
public class TrueFalseQuestion extends Question {
    private final boolean correctAnswer;

    public TrueFalseQuestion(String id, String questionText, int points, boolean correctAnswer) {
        super(id, questionText, points);
        this.correctAnswer = correctAnswer;
    }

    public boolean isCorrectAnswer() {
        return correctAnswer;
    }

    @Override
    public boolean checkAnswer(String userInput) {
        if (userInput == null || userInput.isBlank()) {
            return false;
        }
        String clean = userInput.trim().toLowerCase();
        boolean userBool;
        if (clean.equals("igaz") || clean.equals("i") || clean.equals("true") || clean.equals("t") || clean.equals("1")) {
            userBool = true;
        } else if (clean.equals("hamis") || clean.equals("h") || clean.equals("false") || clean.equals("f") || clean.equals("0")) {
            userBool = false;
        } else {
            return false;
        }
        return userBool == correctAnswer;
    }

    @Override
    public String getFormattedQuestion() {
        return String.format("❓ %s (%d pont)\n   [I] Igaz\n   [H] Hamis\n", getQuestionText(), getPoints());
    }
}
