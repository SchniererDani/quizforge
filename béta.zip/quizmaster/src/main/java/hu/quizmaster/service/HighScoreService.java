package hu.quizmaster.service;

import hu.quizmaster.model.ScoreEntry;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Eredmények kimentése és betöltése szöveges fájlból try-with-resources használatával.
 */
public class HighScoreService {
    private static final String SCORES_FILE = "scores.txt";

    public void saveScore(ScoreEntry scoreEntry) {
        // Append mód try-with-resources-szal
        try (PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter(SCORES_FILE, StandardCharsets.UTF_8, true)))) {
            writer.println(scoreEntry.toFileFormat());
        } catch (IOException e) {
            System.err.println("⚠️ Hiba az eredmény mentésekor: " + e.getMessage());
        }
    }

    public List<ScoreEntry> loadHighScores() {
        List<ScoreEntry> scores = new ArrayList<>();
        File file = new File(SCORES_FILE);
        if (!file.exists()) {
            return scores;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file, StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                try {
                    ScoreEntry entry = ScoreEntry.fromFileFormat(line);
                    scores.add(entry);
                } catch (IllegalArgumentException ignored) {
                }
            }
        } catch (IOException e) {
            System.err.println("⚠️ Hiba az eredmények beolvasásakor: " + e.getMessage());
        }

        // Rendezés a ScoreEntry Comparable interfészével (csökkenő pontszám)
        Collections.sort(scores);
        return scores;
    }
}
