package hu.quizmaster.service;

import hu.quizmaster.model.Question;
import hu.quizmaster.model.Quiz;
import hu.quizmaster.model.ScoreEntry;
import hu.quizmaster.strategy.ScoringStrategy;

import java.util.Scanner;

/**
 * Egy kiválasztott kvíz interaktív lebonyolítása a kiválasztott pontozási stratégiával.
 */
public class QuizRunnerService {
    private final HighScoreService highScoreService;

    public QuizRunnerService(HighScoreService highScoreService) {
        this.highScoreService = highScoreService;
    }

    public void runQuiz(Quiz quiz, ScoringStrategy strategy, Scanner scanner) {
        System.out.println("\n============================================");
        System.out.println("🎯 KVÍZ INDÍTÁSA: " + quiz.getTitle());
        System.out.println("📂 Kategória: " + quiz.getCategory());
        System.out.println("⚙️ Pontozási Stratégia: " + strategy.getStrategyName());
        System.out.println("============================================\n");

        int totalScore = 0;
        int streak = 0;
        int correctCount = 0;

        int index = 1;
        for (Question question : quiz.getQuestions()) {
            System.out.println("[" + index + "/" + quiz.getQuestionCount() + "] Kérdés:");
            System.out.print(question.getFormattedQuestion());
            System.out.print("👉 Válaszod: ");
            String userInput = scanner.nextLine();

            boolean isCorrect = question.checkAnswer(userInput);
            if (isCorrect) {
                streak++;
                correctCount++;
                int pointsEarned = strategy.calculateScore(true, question.getPoints(), streak);
                totalScore += pointsEarned;
                System.out.println("✅ HELYES VÁLASZ! (+" + pointsEarned + " pont, Streak: " + streak + "🔥)\n");
            } else {
                streak = 0;
                int pointsEarned = strategy.calculateScore(false, question.getPoints(), streak);
                totalScore += pointsEarned;
                System.out.println("❌ HIBÁS VÁLASZ! (" + pointsEarned + " pont)\n");
            }
            index++;
        }

        System.out.println("============================================");
        System.out.println("🎉 KVÍZ VÉGE! EREDMÉNYED:");
        System.out.println("Helyes válaszok: " + correctCount + " / " + quiz.getQuestionCount());
        System.out.println("Összesített Pontszám: " + totalScore + " pont");
        System.out.println("============================================\n");

        System.out.print("Szeretnéd elmenteni az eredményedet a dicsőséglistára? (i/n): ");
        String saveOpt = scanner.nextLine();
        if (saveOpt.equalsIgnoreCase("i") || saveOpt.equalsIgnoreCase("igaz") || saveOpt.equalsIgnoreCase("y")) {
            System.out.print("Add meg a neved: ");
            String playerName = scanner.nextLine().trim();
            if (playerName.isEmpty()) playerName = "Játékos";
            ScoreEntry entry = new ScoreEntry(playerName, quiz.getTitle(), totalScore, quiz.getMaxPossiblePoints());
            highScoreService.saveScore(entry);
            System.out.println("💾 Eredmény elmentve! Megtekinthető a Dicsőséglistában.\n");
        }
    }
}
