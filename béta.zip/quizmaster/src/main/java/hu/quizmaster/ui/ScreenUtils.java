package hu.quizmaster.ui;

public class ScreenUtils {

    public static void clearScreen() {
        // ANSI kódos képernyőtörlés, ha támogatott, különben újsorok
        System.out.print("\033[H\033[2J");
        System.out.flush();
        for (int i = 0; i < 3; i++) {
            System.out.println();
        }
    }

    public static void printHeader(String title) {
        System.out.println("============================================");
        System.out.println("  🏆 QUIZMASTER - " + title.toUpperCase());
        System.out.println("============================================");
    }
}
