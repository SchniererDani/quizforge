package hu.quizmaster.ui;

import hu.quizmaster.exception.InvalidQuizFormatException;
import hu.quizmaster.model.Quiz;
import hu.quizmaster.model.ScoreEntry;
import hu.quizmaster.service.HighScoreService;
import hu.quizmaster.service.QuizLoaderService;
import hu.quizmaster.service.QuizRunnerService;
import hu.quizmaster.strategy.PenaltyScoringStrategy;
import hu.quizmaster.strategy.ScoringStrategy;
import hu.quizmaster.strategy.StandardScoringStrategy;
import hu.quizmaster.strategy.StreakScoringStrategy;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

/**
 * Konzolos menürendszer frissülő képernyővel és almenükkel.
 */
public class ConsoleMenu {
    private final QuizLoaderService quizLoaderService;
    private final HighScoreService highScoreService;
    private final QuizRunnerService quizRunnerService;
    private final List<Quiz> loadedQuizzes;
    private ScoringStrategy currentStrategy;
    private final Scanner scanner;

    public ConsoleMenu() {
        this.quizLoaderService = new QuizLoaderService();
        this.highScoreService = new HighScoreService();
        this.quizRunnerService = new QuizRunnerService(highScoreService);
        this.loadedQuizzes = new ArrayList<>();
        this.currentStrategy = new StandardScoringStrategy();
        this.scanner = new Scanner(System.in);

        loadInitialQuizzes();
    }

    private void loadInitialQuizzes() {
        File folder = new File("sample_quizzes");
        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles((dir, name) -> name.endsWith(".txt"));
            if (files != null) {
                for (File file : files) {
                    try {
                        Quiz quiz = quizLoaderService.loadQuizFromFile(file);
                        loadedQuizzes.add(quiz);
                    } catch (Exception ignored) {
                    }
                }
            }
        }
    }

    public void start() {
        boolean running = true;
        while (running) {
            ScreenUtils.clearScreen();
            ScreenUtils.printHeader("FŐMENÜ");
            System.out.println("1. 🎮 Alap kvízek indítása");
            System.out.println("2. 📁 Kvíz bevitel & listázás (.txt)");
            System.out.println("3. ⚙️ Kvíz beállítások (Pontozási stratégia)");
            System.out.println("4. 🏆 Dicsőséglista (High Scores)");
            System.out.println("0. ❌ Kilépés");
            System.out.print("\nVálassz egy menüpontot: ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> showQuizzesSubMenu();
                case "2" -> showQuizImportSubMenu();
                case "3" -> showSettingsSubMenu();
                case "4" -> showHighScoresSubMenu();
                case "0" -> {
                    running = false;
                    System.out.println("\nKöszönjük, hogy a QuizMaster-t használtad! Viszlát!");
                }
                default -> {
                    System.out.println("\n⚠️ Érvénytelen menüpont! Nyomj Enter-t a folytatáshoz...");
                    scanner.nextLine();
                }
            }
        }
    }

    private void showQuizzesSubMenu() {
        boolean sub = true;
        while (sub) {
            ScreenUtils.clearScreen();
            ScreenUtils.printHeader("ALAP KVÍZEK");
            System.out.println("1. 🚀 Előre betöltött kvízek indítása");
            System.out.println("2. 📖 Útmutató / Hogyan kell válaszolni?");
            System.out.println("3. 🔙 Vissza a főmenübe");
            System.out.print("\nVálassz egy opciót: ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> selectAndRunQuiz();
                case "2" -> {
                    showTutorial();
                    scanner.nextLine();
                }
                case "3" -> sub = false;
                default -> {
                    System.out.println("⚠️ Érvénytelen választás!");
                    scanner.nextLine();
                }
            }
        }
    }

    private void selectAndRunQuiz() {
        ScreenUtils.clearScreen();
        ScreenUtils.printHeader("KVÍZ VÁLASZTÁS");
        if (loadedQuizzes.isEmpty()) {
            System.out.println("Nincs egyetlen betöltött kvíz sem. Importálj egyet a 2. menüpontban!");
            System.out.println("Nyomj Enter-t...");
            scanner.nextLine();
            return;
        }

        int idx = 1;
        for (Quiz quiz : loadedQuizzes) {
            System.out.printf("%d. %s [%s] (%d kérdés)\n", idx++, quiz.getTitle(), quiz.getCategory(), quiz.getQuestionCount());
        }
        System.out.println("0. Vissza");
        System.out.print("\nVálassz kvízt (szám): ");

        try {
            int sel = Integer.parseInt(scanner.nextLine().trim());
            if (sel > 0 && sel <= loadedQuizzes.size()) {
                Quiz selectedQuiz = loadedQuizzes.get(sel - 1);
                quizRunnerService.runQuiz(selectedQuiz, currentStrategy, scanner);
                System.out.println("Nyomj Enter-t a folytatáshoz...");
                scanner.nextLine();
            }
        } catch (NumberFormatException e) {
            System.out.println("⚠️ Hibás számformátum.");
            scanner.nextLine();
        }
    }

    private void showTutorial() {
        ScreenUtils.clearScreen();
        ScreenUtils.printHeader("TUTORIAL - ÚTMUTATÓ");
        System.out.println("💡 Válaszadási szabályok:");
        System.out.println(" - Feleletválasztós (A-B-C-D): Írd be a helyes opció betűjét (pl. 'A' vagy 'b').");
        System.out.println(" - Igaz / Hamis: Írd be, hogy 'igaz' / 'hamis' vagy 'i' / 'h'.");
        System.out.println(" - Szöveges válasz: Írd be a pontos kifejezést vagy számot.");
        System.out.println("\nNyomj Enter-t a visszalépéshez...");
    }

    private void showQuizImportSubMenu() {
        boolean sub = true;
        while (sub) {
            ScreenUtils.clearScreen();
            ScreenUtils.printHeader("KVÍZ BEVITEL & LISTÁZÁS");
            System.out.println("1. 📥 Új .txt kvíz fájl betöltése");
            System.out.println("2. 📋 Meglévő kvízek listázása név szerint (rendezve)");
            System.out.println("3. 🔙 Vissza a főmenübe");
            System.out.print("\nVálassz egy opciót: ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> importQuizFile();
                case "2" -> listQuizzesSorted();
                case "3" -> sub = false;
                default -> scanner.nextLine();
            }
        }
    }

    private void importQuizFile() {
        ScreenUtils.clearScreen();
        ScreenUtils.printHeader("TXT KVÍZ IMPORTÁLÁSA");
        System.out.print("Add meg a TXT fájl elérési útját (pl. sample_quizzes/java_basics.txt): ");
        String path = scanner.nextLine().trim();
        File file = new File(path);

        try {
            Quiz newQuiz = quizLoaderService.loadQuizFromFile(file);
            loadedQuizzes.add(newQuiz);
            System.out.println("✅ Sikeres importálás! Betöltött kvíz: " + newQuiz.getTitle());
        } catch (InvalidQuizFormatException e) {
            System.out.println("❌ Formátum hiba: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("❌ Fájl olvasási hiba: " + e.getMessage());
        }
        System.out.println("Nyomj Enter-t a folytatáshoz...");
        scanner.nextLine();
    }

    private void listQuizzesSorted() {
        ScreenUtils.clearScreen();
        ScreenUtils.printHeader("MEGLÉVŐ KVÍZEK (ABC RENDEZVE)");
        if (loadedQuizzes.isEmpty()) {
            System.out.println("Nincs megjeleníthető kvíz.");
        } else {
            // Név szerinti rendezés Comparator segítségével
            List<Quiz> sorted = new ArrayList<>(loadedQuizzes);
            sorted.sort(Comparator.comparing(Quiz::getTitle, String.CASE_INSENSITIVE_ORDER));
            for (Quiz q : sorted) {
                System.out.println("• " + q);
            }
        }
        System.out.println("\nNyomj Enter-t a folytatáshoz...");
        scanner.nextLine();
    }

    private void showSettingsSubMenu() {
        boolean sub = true;
        while (sub) {
            ScreenUtils.clearScreen();
            ScreenUtils.printHeader("PONTOZÁSI STRATÉGIA BEÁLLÍTÁSA");
            System.out.println("Jelenlegi stratégia: 🌟 " + currentStrategy.getStrategyName());
            System.out.println("   (" + currentStrategy.getStrategyDescription() + ")\n");
            System.out.println("1. Standard Pontozás");
            System.out.println("2. Streak Bónusz Pontozás (több jó válasz = több pont)");
            System.out.println("3. Büntetőpontos Pontozás (hibás válasz = -2 pont)");
            System.out.println("4. 🔙 Vissza a főmenübe");
            System.out.print("\nVálassz stratégiát: ");

            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> {
                    currentStrategy = new StandardScoringStrategy();
                    System.out.println("✅ Átváltva: Standard Pontozás");
                }
                case "2" -> {
                    currentStrategy = new StreakScoringStrategy();
                    System.out.println("✅ Átváltva: Streak Bónusz Pontozás");
                }
                case "3" -> {
                    currentStrategy = new PenaltyScoringStrategy();
                    System.out.println("✅ Átváltva: Büntetőpontos Pontozás");
                }
                case "4" -> sub = false;
                default -> {}
            }
        }
    }

    private void showHighScoresSubMenu() {
        ScreenUtils.clearScreen();
        ScreenUtils.printHeader("DICSŐSÉGLISTA (HIGH SCORES)");
        List<ScoreEntry> scores = highScoreService.loadHighScores();
        if (scores.isEmpty()) {
            System.out.println("Még nincsenek elmentett eredmények.");
        } else {
            System.out.println("Helyezés | Játékos        | Kvíz                 | Pontszám   | Dátum");
            System.out.println("-------------------------------------------------------------------------");
            int rank = 1;
            for (ScoreEntry s : scores) {
                System.out.printf("%-8d | %s\n", rank++, s);
            }
        }
        System.out.println("\nNyomj Enter-t a visszalépéshez...");
        scanner.nextLine();
    }
}
