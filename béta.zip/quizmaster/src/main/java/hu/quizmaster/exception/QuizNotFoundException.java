package hu.quizmaster.exception;

/**
 * Nem létező vagy nem található kvíz esetén kiváltott kivétel.
 */
public class QuizNotFoundException extends QuizMasterException {
    public QuizNotFoundException(String quizId) {
        super("A megadott azonosítójú kvíz nem található: " + quizId);
    }
}
