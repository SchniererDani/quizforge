package hu.quizmaster.exception;

/**
 * Érvénytelen felhasználói válaszbemenet esetén kiváltott kivétel.
 */
public class InvalidAnswerException extends QuizMasterException {
    public InvalidAnswerException(String message) {
        super(message);
    }
}
