package hu.quizmaster.exception;

/**
 * Hibás formátumú TXT kvízfájl beolvasásakor kiváltott kivétel.
 */
public class InvalidQuizFormatException extends QuizMasterException {
    private final int lineNumber;

    public InvalidQuizFormatException(String message, int lineNumber) {
        super(String.format("Formátum hiba a %d. sorban: %s", lineNumber, message));
        this.lineNumber = lineNumber;
    }

    public int getLineNumber() {
        return lineNumber;
    }
}
