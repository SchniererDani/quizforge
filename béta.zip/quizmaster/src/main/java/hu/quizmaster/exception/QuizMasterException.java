package hu.quizmaster.exception;

/**
 * Alapvető saját domain kivétel osztály.
 */
public class QuizMasterException extends Exception {
    public QuizMasterException(String message) {
        super(message);
    }

    public QuizMasterException(String message, Throwable cause) {
        super(message, cause);
    }
}
