package hu.quizmaster.strategy;

/**
 * Standard pontozás: helyes válaszért megkapja a kérdés alapértékét, hibásért 0 pont.
 */
public class StandardScoringStrategy implements ScoringStrategy {

    @Override
    public int calculateScore(boolean isCorrect, int questionBasePoints, int currentStreak) {
        return isCorrect ? questionBasePoints : 0;
    }

    @Override
    public String getStrategyName() {
        return "Standard Pontozás";
    }

    @Override
    public String getStrategyDescription() {
        return "Helyes válasz = Alap pontszám, Hibás válasz = 0 pont.";
    }
}
