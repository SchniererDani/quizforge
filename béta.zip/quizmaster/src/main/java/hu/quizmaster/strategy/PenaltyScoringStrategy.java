package hu.quizmaster.strategy;

/**
 * Büntetőpontos stratégia: hibás válasz esetén pontlevonás jár.
 */
public class PenaltyScoringStrategy implements ScoringStrategy {

    @Override
    public int calculateScore(boolean isCorrect, int questionBasePoints, int currentStreak) {
        if (isCorrect) {
            return questionBasePoints;
        }
        return -2; // 2 pont levonás hibás válasz esetén
    }

    @Override
    public String getStrategyName() {
        return "Büntetőpontos Pontozás";
    }

    @Override
    public String getStrategyDescription() {
        return "Helyes válasz = Alap pont, Hibás válasz = -2 büntetőpont.";
    }
}
