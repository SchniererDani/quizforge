package hu.quizmaster.strategy;

/**
 * Streak bónusz pontozás: egymás utáni jó válaszok esetén extra pont jár.
 */
public class StreakScoringStrategy implements ScoringStrategy {

    @Override
    public int calculateScore(boolean isCorrect, int questionBasePoints, int currentStreak) {
        if (!isCorrect) {
            return 0;
        }
        int bonus = Math.max(0, currentStreak - 1) * 2;
        return questionBasePoints + bonus;
    }

    @Override
    public String getStrategyName() {
        return "Streak Bónusz Pontozás";
    }

    @Override
    public String getStrategyDescription() {
        return "Egymás utáni jó válaszokért (streak) kérdésenként +2 extra bónuszpont jár!";
    }
}
