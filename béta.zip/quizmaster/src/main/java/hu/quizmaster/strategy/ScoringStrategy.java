package hu.quizmaster.strategy;

/**
 * Strategy tervezési minta interfész a pontozási szabályok dinamikus kezeléséhez.
 */
public interface ScoringStrategy {
    
    /**
     * Kiszámolja a kérdésre adott válaszért járó pontszámot.
     * @param isCorrect helyes volt-e a válasz
     * @param questionBasePoints a kérdés alapértelmezett pontértéke
     * @param currentStreak az egymás után adott helyes válaszok száma
     * @return a kiszámított pontérték
     */
    int calculateScore(boolean isCorrect, int questionBasePoints, int currentStreak);

    String getStrategyName();
    String getStrategyDescription();
}
