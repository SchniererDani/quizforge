package hu.quizmaster;

import hu.quizmaster.ui.ConsoleMenu;

/**
 * Az alkalmazás belépési pontja.
 */
public class Main {
    public static void main(String[] args) {
        ConsoleMenu menu = new ConsoleMenu();
        menu.start();
    }
}
