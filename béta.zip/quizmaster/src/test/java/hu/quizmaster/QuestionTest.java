package hu.quizmaster;

import hu.quizmaster.model.MultipleChoiceQuestion;
import hu.quizmaster.model.TextAnswerQuestion;
import hu.quizmaster.model.TrueFalseQuestion;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class QuestionTest {

    @Test
    public void testMultipleChoiceQuestion() {
        MultipleChoiceQuestion q = new MultipleChoiceQuestion("q1", "Mi Java?", 10, List.of("Nyelv", "Sajt", "Auto"), 0);
        assertTrue(q.checkAnswer("A"));
        assertTrue(q.checkAnswer("a"));
        assertTrue(q.checkAnswer("1"));
        assertTrue(q.checkAnswer("Nyelv"));
        assertFalse(q.checkAnswer("B"));
    }

    @Test
    public void testTrueFalseQuestion() {
        TrueFalseQuestion q = new TrueFalseQuestion("q2", "Java nyelv?", 5, true);
        assertTrue(q.checkAnswer("igaz"));
        assertTrue(q.checkAnswer("i"));
        assertTrue(q.checkAnswer("true"));
        assertFalse(q.checkAnswer("hamis"));
    }

    @Test
    public void testTextAnswerQuestion() {
        TextAnswerQuestion q = new TextAnswerQuestion("q3", "Melyik kulcsszó?", 10, "final");
        assertTrue(q.checkAnswer("final"));
        assertTrue(q.checkAnswer("FINAL"));
        assertFalse(q.checkAnswer("const"));
    }
}
