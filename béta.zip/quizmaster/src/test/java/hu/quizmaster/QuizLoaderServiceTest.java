package hu.quizmaster;

import hu.quizmaster.exception.InvalidQuizFormatException;
import hu.quizmaster.model.Quiz;
import hu.quizmaster.service.QuizLoaderService;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;

public class QuizLoaderServiceTest {

    @Test
    public void testLoadValidQuiz() throws IOException, InvalidQuizFormatException {
        QuizLoaderService loader = new QuizLoaderService();
        File sample = new File("sample_quizzes/java_basics.txt");
        if (sample.exists()) {
            Quiz quiz = loader.loadQuizFromFile(sample);
            assertNotNull(quiz);
            assertTrue(quiz.getQuestionCount() > 0);
        }
    }
}
