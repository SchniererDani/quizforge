package hu.quizmaster;

import hu.quizmaster.strategy.PenaltyScoringStrategy;
import hu.quizmaster.strategy.StandardScoringStrategy;
import hu.quizmaster.strategy.StreakScoringStrategy;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ScoringStrategyTest {

    @Test
    public void testStandardScoring() {
        StandardScoringStrategy strategy = new StandardScoringStrategy();
        assertEquals(10, strategy.calculateScore(true, 10, 1));
        assertEquals(0, strategy.calculateScore(false, 10, 1));
    }

    @Test
    public void testStreakScoring() {
        StreakScoringStrategy strategy = new StreakScoringStrategy();
        assertEquals(10, strategy.calculateScore(true, 10, 1));
        assertEquals(12, strategy.calculateScore(true, 10, 2)); // +2 bonus
        assertEquals(14, strategy.calculateScore(true, 10, 3)); // +4 bonus
        assertEquals(0, strategy.calculateScore(false, 10, 1));
    }

    @Test
    public void testPenaltyScoring() {
        PenaltyScoringStrategy strategy = new PenaltyScoringStrategy();
        assertEquals(10, strategy.calculateScore(true, 10, 1));
        assertEquals(-2, strategy.calculateScore(false, 10, 1));
    }
}
