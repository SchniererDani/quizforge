# 🏆 QuizMaster - Java OOP Konzolos Kvíz Alkalmazás

Az alkalmazás egy interaktív, konzol alapú (CLI) kvíz és tesztelő szoftver, amely a **Miskolci Egyetem / Prog 2 tanegység** egyéni nagyprojekt követelményei alapján készült.

---

## 📖 Projekt Összefoglaló & Architektúra

Az alkalmazás segítségével a felhasználók különböző témájú kvízeket tölthetnek ki, új kvízeket importálhatnak `.txt` fájlokból, egyedi pontozási stratégiákat állíthatnak be, és elmenthetik az elért eredményeiket egy dicsőséglistára.

### 🛠️ Megvalósított Kötelező OOP Követelmények

1. **Enkapszuláció (Encapsulation):**
   - Minden domain modell (`Question`, `Quiz`, `ScoreEntry`) privát mezőkkel rendelkezik, és kontrollált hozzáférést biztosít getter/setter metódusokon keresztül.
2. **Absztrakció, Öröklődés & Polimorfizmus:**
   - Absztrakt ősosztály: `Question`
   - Leszármazottak: `MultipleChoiceQuestion`, `TrueFalseQuestion`, `TextAnswerQuestion`
   - Polimorf viselkedés: A `checkAnswer()` és `getFormattedQuestion()` metódusok felülbírálása futásidőben határozza meg a válaszok ellenőrzését és formázását.
3. **Kötelező Tervezési Minta (Design Pattern):**
   - **Strategy Pattern (Pontozási Stratégia):** A `ScoringStrategy` interfész és annak megvalósításai (`StandardScoringStrategy`, `StreakScoringStrategy`, `PenaltyScoringStrategy`) lehetővé teszik a pontszámítási logika dinamikus cseréjét futásidőben.
4. **Adatperszisztencia (Data Persistence):**
   - A kvízek beolvasása `.txt` fájlokból és az eredmények mentése a `scores.txt` fájlba `try-with-resources` blokkokkal történik.
5. **Generikus Kollekciók & Rendezés:**
   - `List<Question>`, `List<Quiz>`, `List<ScoreEntry>` generikus adatszerkezetek.
   - Dicsőséglista rendezése a `ScoreEntry` osztály által megvalósított `Comparable<ScoreEntry>` interfész és `Comparator` segítségével.
6. **Saját Kivételkezelés (Custom Exceptions):**
   - Domain-specifikus kivételek: `QuizMasterException`, `InvalidQuizFormatException`, `InvalidAnswerException`, `QuizNotFoundException`.

---

## 🚀 Fordítás és Futtatás (Build & Run)

A projekt standard **Maven** szerkezetű, IntelliJ IDEA-ban közvetlenül megnyitható.

### 1. Fordítás
```bash
mvn clean compile
```

### 2. Unit Tesztek Futtatása
```bash
mvn test
```

### 3. Alkalmazás Futtatása Parancssorból
```bash
mvn exec:java
```

---

## 📂 Projektstruktúra

```text
quizmaster/
 ├── pom.xml
 ├── .gitignore
 ├── README.md
 ├── docs/
 │    └── user_stories.md
 ├── sample_quizzes/
 │    ├── java_basics.txt
 │    └── general_knowledge.txt
 └── src/
      ├── main/
      │    └── java/
      │         └── hu/quizmaster/
      │              ├── model/        (Question, MultipleChoiceQuestion, TrueFalseQuestion, TextAnswerQuestion, Quiz, ScoreEntry)
      │              ├── strategy/     (ScoringStrategy, StandardScoringStrategy, StreakScoringStrategy, PenaltyScoringStrategy)
      │              ├── exception/    (QuizMasterException, InvalidQuizFormatException, etc.)
      │              ├── service/      (QuizLoaderService, QuizRunnerService, HighScoreService)
      │              ├── ui/           (ConsoleMenu, ScreenUtils)
      │              └── Main.java
      └── test/
           └── java/
                └── hu/quizmaster/     (JUnit 5 unit tesztek)
```

---

## 👤 Szerző
- **Projekt:** QuizMaster Console Application
- **Technológia:** Java 17+, Maven, JUnit 5
